﻿namespace FiguresMathfOperations
{
    public abstract class Figure
    {
        public abstract double CalculateArea();
    }
}
