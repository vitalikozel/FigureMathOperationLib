﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using FiguresMathfOperations;
using FiguresMathfOperations.Figures.FiguresType;
using System;

namespace TestsForFigureMathfOperations.CircleTests
{
    [TestClass]
    public class CircleTests
    {
        [TestMethod]
        public void CurrectCalculateRadius()
        {
            Figure circle = new Circle(1);

            double expected = Math.PI;

            double area = circle.CalculateArea();

            Assert.AreEqual(expected, area);
        }
    }
}
