﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using FiguresMathfOperations.Figures.FiguresType;
using FiguresMathfOperations;

namespace TestsForFigureMathfOperations
{
    [TestClass]
    public class TraingleTests
    {
        [TestMethod]
        public void CalculateAreaTriangle()
        {
            double[] sides = new double[] { 24, 25, 7 };
            double expected = 84;

            Figure triangle = new Triangle(sides);

            double area = triangle.CalculateArea();

            Assert.AreEqual(expected, area);
        }

        [TestMethod]
        public void IsReqtangularTriangle()
        {
            double[] sides = new double[] { 24, 25, 7 };
            bool expected = true;

            Triangle triangle = new Triangle(sides);

            bool isReqtangular = triangle.IsRectangular();

            Assert.AreEqual(expected, isReqtangular);
        }
    }
}
